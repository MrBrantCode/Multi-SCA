
fn main() {
    println!("Vulnerable test project: wasmtime 38.0.3 + gix-features 0.40.0");
}
