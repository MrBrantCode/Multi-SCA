def main() -> None:
    print("hello from python_sample")


if __name__ == "__main__":
    main()


