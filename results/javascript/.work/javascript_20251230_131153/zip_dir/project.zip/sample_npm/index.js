const _ = require("lodash");

console.log(_.chunk([1, 2, 3, 4, 5], 2));


